package com.drc.practical.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.drc.practical.entity.Teacher;
import com.drc.practical.service.TeacherService;

@RestController
@RequestMapping(value = "/teacher")
public class TeacherController {

	@Autowired
	private TeacherService teacherService;

	@PostMapping("/register")
	public ResponseEntity<Object> registerTeacher(@RequestBody Teacher teacher) {

		teacherService.registerTeacher(teacher);

		return ResponseEntity.ok("Teacher register successfully");

	}

}
