package com.drc.practical.security;

import java.util.ArrayList;
import java.util.Collection;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.drc.practical.entity.Teacher;
import com.drc.practical.service.TeacherService;

@Configuration
public class AuthenticationService implements UserDetailsService {

	@Autowired
	private TeacherService teacherService;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
				.getRequest();

		Teacher teacher = teacherService.getTeacherByEmail(email);

		// if teacher with email not exists then throw error msg
		if (null == teacher)
			throw new UsernameNotFoundException("User not exist");

		if (!isPasswordValid(teacher, request))
			throw new BadCredentialsException("Invalid password");

		return new org.springframework.security.core.userdetails.User(teacher.getEmail(), teacher.getPassword(), true,
				true, true, true, getSimpleGrantedAuthorities(teacher.getRole()));
	}

	/**
	 * Set role in authorities for teacher
	 * 
	 * @param role
	 * @return
	 */
	private Collection<GrantedAuthority> getSimpleGrantedAuthorities(String role) {

		Collection<GrantedAuthority> grantedAuthorities = new ArrayList<GrantedAuthority>();

		grantedAuthorities.add(new SimpleGrantedAuthority(role));

		return grantedAuthorities;

	}

	/**
	 * Checks that given password is valid or not
	 * 
	 * @param teacher
	 * @param request
	 * @return
	 */
	private boolean isPasswordValid(Teacher teacher, HttpServletRequest request) {

		if (null != teacher && !StringUtils.isEmpty(teacher.getPassword()))
			return passwordEncoder.matches(request.getParameter("password"), teacher.getPassword());

		return false;

	}

}
