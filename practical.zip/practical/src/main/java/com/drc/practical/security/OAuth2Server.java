package com.drc.practical.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;

@Configuration
@EnableAuthorizationServer
public class OAuth2Server extends AuthorizationServerConfigurerAdapter {

	private static final String PROP_CLIENTID = "drc-demo-client";
	private static final String PROP_SECRET = "drc-demo-secret";
	private static final int PROP_ACCESS_TOKEN_VALIDITY_SECONDS = 3600 * 24 * 365; // 1 Year
	private static final int PROP_REFRESH_TOKEN_VALIDITY_SECONDS = -1; // Lifetime
	private static final String READ = "read";
	private static final String WRITE = "write";
	private static final String TRUST = "trust";
	private static final String PASSWORD = "password";
	private static final String AUTHORIZATION_CODE = "authorization_code";
	private static final String REFRESH_TOKEN = "refresh_token";
	private static final String IMPLICIT = "implicit";

	@Autowired
	private TokenStore tokenStore;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	public AuthenticationManager authenticationManager;

	@Autowired
	private AuthenticationService authenticationService;

	@Override
	public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {

		endpoints.authenticationManager(authenticationManager).tokenStore(tokenStore)
				.userDetailsService(authenticationService);

	}

	@Override
	public void configure(ClientDetailsServiceConfigurer clients) throws Exception {

		String secretEncoded = passwordEncoder.encode(PROP_SECRET);

		clients.inMemory().withClient(PROP_CLIENTID).scopes(READ, WRITE, TRUST)
				.authorizedGrantTypes(PASSWORD, AUTHORIZATION_CODE, REFRESH_TOKEN, IMPLICIT).secret(secretEncoded)
				.accessTokenValiditySeconds(PROP_ACCESS_TOKEN_VALIDITY_SECONDS)
				.refreshTokenValiditySeconds(PROP_REFRESH_TOKEN_VALIDITY_SECONDS);

	}

}
