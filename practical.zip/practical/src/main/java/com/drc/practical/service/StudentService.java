package com.drc.practical.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.drc.practical.entity.Student;
import com.drc.practical.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;

	/**
	 * Get all student by pagination
	 * 
	 * @param length
	 * @param start
	 * 
	 * @return
	 */
	public ResponseEntity<Object> getAllStudents(Integer start, Integer length) {

		// if start and length not given then set 5 by default
		start = (start == null) ? 0 : start;
		length = (length == null) ? 5 : length;

		return ResponseEntity.ok(studentRepository.findAll(PageRequest.of((start / length), length)));
	}

	/**
	 * Get student by id
	 * 
	 * @param id
	 * @return
	 */
	public ResponseEntity<Object> getStudentById(Long id) {

		return ResponseEntity.ok(studentRepository.findById(id));
	}

	/**
	 * Save/Update student in single api
	 * 
	 * @param student
	 * @return
	 */
	public ResponseEntity<Object> saveStudent(Student student) {

		studentRepository.save(student);

		return ResponseEntity.ok("Saved sucessfully");
	}

	/**
	 * Delete student by id
	 * 
	 * @param id
	 * @return
	 */
	public ResponseEntity<Object> deleteStudentById(Long id) {

		studentRepository.deleteById(id);

		return ResponseEntity.ok("Deleted sucessfully");
	}

}
