package com.drc.practical.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.drc.practical.entity.Teacher;
import com.drc.practical.repository.TeacherRepository;

@Service
public class TeacherService {

	@Autowired
	private TeacherRepository teacherRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	public Teacher getTeacherByEmail(String email) {

		return teacherRepository.findByEmail(email);
	}

	public void registerTeacher(Teacher teacher) {

		teacher.setPassword(this.passwordEncoder.encode(teacher.getPassword()));

		this.teacherRepository.save(teacher);

	}
}
